//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Smile.rc
//
#define IDS_Smile                       1
#define IDD_ABOUTBOX_Smile              1
#define IDB_Smile                       1
#define IDI_ABOUTDLL                    1
#define IDS_Smile_PPG                   2
#define IDS_Smile_PPG_CAPTION           100
#define IDD_PROPPAGE_Smile              100
#define IDS_SmileColor_PPG              101
#define IDS_SmileFont_PPG               102
#define IDC_CHECK1                      201
#define IDC_EDIT1                       202

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
