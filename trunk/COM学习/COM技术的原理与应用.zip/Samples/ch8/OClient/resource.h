//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by oclient.rc
//
#define IDR_MAINFRAME                   2
#define IDR_OCLIENTTYPE                 3
#define IDD_ABOUTBOX                    100
#define IDP_BUSY                        101
#define ID_OBJECT_POPUP_MENU            102
#define IDS_PRIVATE_CF_DESCR            102
#define IDR_OCLIENTTYPE_CNTR_IP         104
#define IDP_CLIPBOARD_CUT_FAILED        0x201
#define IDP_CLIPBOARD_COPY_FAILED       0x202
#define IDP_GET_FROM_CLIPBOARD_FAILED   0x203
#define IDP_FAILED_TO_CREATE            0x204
#define IDP_SAVEINCOMPLETE              0x205
#define IDP_CLIPBOARD_ZERO_SIZE         0x206
#define IDP_AFXOLEINIT_FAILED           519
#define ID_OBJECT_TRACK_SIZE            2000
#define ID_CANCEL_INPLACE               2002
#define ID_OBJECT_DISPLAYCONTENT        2003
#define ID_OBJECT_DISPLAYASICON         2004
#define ID_OBJECT_CHANGEICON            2005
#define ID_EDIT_CLONE                   2006
#define ID_OBJECT_RESETSIZE             2009
#define ID_OLE_CHANGE_SOURCE            2012

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         2013
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           200
#endif
#endif
