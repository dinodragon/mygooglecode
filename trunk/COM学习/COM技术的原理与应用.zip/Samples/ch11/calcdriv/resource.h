//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by calcdriv.rc
//
#define IDR_MAINFRAME                   2
#define IDP_UNABLE_TO_CREATE            3
#define IDP_UNABLE_TO_SHOW              4
#define IDP_OLE_INIT_FAILED             100
#define IDC_EXPRESSION                  101
#define IDD_CALCDRIV                    102
#define IDC_GO                          103
#define IDC_SINGLE_STEP                 104
#define IDC_LAST_ACCUM                  105
#define IDD_LAST_OPERAND                106
#define IDC_REFRESH                     107
#define IDD_LAST_OPERATOR               108

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         108
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
