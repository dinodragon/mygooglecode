//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mfccalc.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDD_MFCCALC_DIALOG              102
#define IDS_ERROR                       102
#define IDP_UNABLE_TO_SHOW_CALC         103
#define IDR_MAINFRAME                   128
#define IDB_0                           1000
#define IDB_1                           1001
#define IDB_2                           1002
#define IDB_3                           1003
#define IDB_4                           1004
#define IDB_5                           1005
#define IDB_6                           1006
#define IDB_7                           1007
#define IDB_8                           1008
#define IDB_9                           1009
#define IDB_PLUS                        1010
#define IDB_MINUS                       1011
#define IDB_TIMES                       1012
#define IDB_DIVIDE                      1013
#define IDC_INVISIBLE_FOCUS             1016
#define IDB_CLOSE                       1017
#define IDB_EQUAL                       1020
#define IDB_CLEAR                       1021
#define IDE_ACCUM                       1030
#define ID_NOTHING                      32789

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
