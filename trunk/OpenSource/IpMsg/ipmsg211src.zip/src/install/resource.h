//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by install.rc
//
#define IDS_NOTNEWSHELL                 10
#define IDS_SETUPCOMPLETE               11
#define IDS_UNINSTCOMPLETE              12
#define IDS_TERMINATE                   13
#define IDS_NOTCREATEDIR                14
#define IDS_NOTCREATEFILE               15
#define IDS_START                       16
#define IDS_REGIPMSG                    17
#define IDS_MKDIR                       18
#define IDS_RMDIR                       19
#define INSTALL_SHEET                   101
#define SETUP_ICON                      104
#define IPMSG_ICON                      105
#define MKDIR_BUTTON                    110
#define RMDIR_BUTTON                    111
#define INSTALL_DIALOG                  149
#define INPUT_DIALOG                    150
#define UNINSTALL_SHEET                 151
#define INSTALL_STATIC                  1133
#define FILE_EDIT                       1135
#define FILE_BUTTON                     1136
#define STARTUP_CHECK                   1137
#define RESETUP_EDIT                    1137
#define DESKTOP_CHECK                   1138
#define PROGRAM_CHECK                   1139
#define INPUT_EDIT                      1139
#define SETUP_RADIO                     1143
#define RESETUP_RADIO                   1145
#define UNINSTALL_RADIO                 1147
#define UNINSTTEST_CHECK                1151
#define DELPUBKEY_CHECK                 1152

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        154
#define _APS_NEXT_COMMAND_VALUE         30034
#define _APS_NEXT_CONTROL_VALUE         1153
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
