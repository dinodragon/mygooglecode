/*static char *version_id = 
	"@(#)Copyright (C) H.Shirouzu 2010   version.h	Ver2.10"; */
/* ========================================================================
	Project  Name			: IP Messenger for Win32
	Module Name				: Version
	Create					: 2010-05-23(Sun)
	Update					: 2010-05-23(Sun)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#ifndef VERSION_H
#define VERSION_H

char *GetVersionStr(void);

#endif

