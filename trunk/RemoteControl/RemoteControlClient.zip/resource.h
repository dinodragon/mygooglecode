//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDDEFAULT                       3
#define IDB_BITMAP1                     101
#define IDI_ICON1                       102
#define IDB_NORECEIVE                   102
#define IDB_BITMAP                      105
#define IDR_MENU1                       106
#define IDB_SEND                        107
#define IDB_NOSEND                      108
#define IDB_BITMAP2                     109
#define IDB_RECEIVE                     109
#define IDD_SERVERIP                    111
#define IDD_GRIDSPACING                 112
#define IDD_COMPRESSION                 113
#define IDD_COLORMODE                   114
#define IDC_SERVERIP                    1000
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_HGRID                       1001
#define IDC_VGRID                       1002
#define IDC_HGRIDC                      1003
#define IDC_VGRIDC                      1004
#define IDC_RADIO0                      1009
#define IDC_RADIO10                     1010
#define IDC_RADIO11                     1011
#define IDC_RADIO12                     1012
#define IDC_RADIO13                     1013
#define IDM_EXIT                        40001
#define IDM_REFRESH                     40002
#define IDM_CONNECT                     40002
#define IDM_DISCONNECT                  40004
#define IDM_COMPRESSION                 40005
#define IDM_GRIDSPACING                 40006
#define IDM_COLORMODE                   40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
