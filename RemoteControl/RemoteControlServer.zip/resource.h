//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDB_BITMAP1                     101
#define IDI_ICON1                       102
#define IDB_BITMAP                      105
#define IDR_MENU1                       106
#define IDB_BITMAP2                     109
#define IDD_COMPRESSION                 113
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define IDC_RADIO4                      1003
#define IDC_RADIO5                      1004
#define IDC_RADIO6                      1005
#define IDC_RADIO7                      1006
#define IDC_RADIO8                      1007
#define IDC_RADIO9                      1008
#define IDC_RADIOA                      1009
#define IDM_EXIT                        40001
#define IDM_STARTSERVER                 40004
#define IDM_STOPSERVER                  40005
#define IDM_COMPRESSION                 40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
