// CallBack Function Prototype and Window Initialization Prototypes
HWND				WinInit(HINSTANCE hInst,int iShow);
LRESULT	CALLBACK	WndProc (HWND hWnd,UINT iMsg,WPARAM wParam,LPARAM lParam);
