//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MiniPieppc.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_URL                         101
#define IDR_MAINFRAME                   128
#define IDM_EDIT                        200
#define IDC_TYPE_LIST                   1000
#define IDC_EDIT_URL                    1001
#define ID_VIEW_ADDRESSBAR              32773
#define IDM_FORWARD                     32774
#define IDM_BACK                        32775
#define IDM_HOME                        32776
#define IDM_REFRESH                     32777
#define IDM_STOP                        32778
#define IDM_OPENURL                     32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
