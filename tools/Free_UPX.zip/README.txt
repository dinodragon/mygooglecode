Name: Free UPX
Version: 1.4
License: Freeware
Date: Sep 16, 2010
Author: Jacek Pazera
Web page PL: http://www.pazera-software.pl/products/free-upx/
Web page EN: http://www.pazera-software.com/products/free-upx/
UPX page: http://upx.sourceforge.net/

////////////////////////////////////////////////////////////////////////////////

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY or SUPPORT. YOU USE IT AT YOUR OWN RISK.
  
////////////////////////////////////////////////////////////////////////////////